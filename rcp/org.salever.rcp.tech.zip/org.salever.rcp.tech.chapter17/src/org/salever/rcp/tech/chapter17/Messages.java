package org.salever.rcp.tech.chapter17;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "org.salever.rcp.tech.chapter17.messages"; //$NON-NLS-1$
	public static String View_0;
	public static String View_1;
	public static String View_10;
	public static String View_11;
	public static String View_12;
	public static String View_13;
	public static String View_14;
	public static String View_15;
	public static String View_16;
	public static String View_2;
	public static String View_3;
	public static String View_4;
	public static String View_5;
	public static String View_6;
	public static String View_7;
	public static String View_8;
	public static String View_9;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
