/*******************************************************************************
 * Copyright (c) 2000, 2010 salever. All rights reserved. 
 *
 *******************************************************************************/
package org.salever.rcp.tech.chapter19;

/**
 * @author salever
 *
 */
public class DebugConstants {

	public static final String LAUNCH_CONFIGURATION_TYPE = "org.salever.rcp.debug.demo.xmlLaunchConfigurationType";
	public static final String XML_FILE = "XML";
	public static final String _TYPE = "TYPE";


}
